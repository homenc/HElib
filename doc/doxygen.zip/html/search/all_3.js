var searchData=
[
  ['decodeplaintext',['decodePlaintext',['../class_p_algebra_mod_derived.html#a2e2b3c630c790504cd48f1647deaa494',1,'PAlgebraModDerived']]],
  ['decrypt',['Decrypt',['../class_f_h_e_sec_key.html#abf4d396c50a3384856bd36a1b2b2e3a8',1,'FHESecKey']]],
  ['deep_5fclone',['deep_clone',['../classdeep__clone.html',1,'']]],
  ['depth',['depth',['../class_general_benes_network.html#ac765d85d30ad5e651afc5919c532acf8',1,'GeneralBenesNetwork']]],
  ['digits',['digits',['../class_f_h_econtext.html#a364e0e4f9d6fc4403e76481b1541a56b',1,'FHEcontext']]],
  ['dimension',['dimension',['../class_encrypted_array_base.html#a073ecca4315883f4bc6653aecb1a3d40',1,'EncryptedArrayBase']]],
  ['disjoint',['disjoint',['../_index_set_8h.html#a6ad52049785829c42f58da1a9a7689ad',1,'IndexSet.h']]],
  ['disjointfrom',['disjointFrom',['../class_index_set.html#afc89789b0feb0f0f2483988bd33c8566',1,'IndexSet']]],
  ['divc',['divc',['../_numb_th_8h.html#a12030c02bf9609c62a4d9a314a42cc14',1,'NumbTh.h']]],
  ['divideby2',['divideBy2',['../class_ctxt.html#a5db20ecbdc270b517c657e4a8b12105d',1,'Ctxt']]],
  ['dlog',['dLog',['../class_p_algebra.html#a08e23c1cb902c35456df7b20db1eeb3b',1,'PAlgebra']]],
  ['doublecrt',['DoubleCRT',['../class_double_c_r_t.html',1,'DoubleCRT'],['../class_double_c_r_t.html#a10cdf5d055b30831b958ca1bf58bdbd9',1,'DoubleCRT::DoubleCRT(const ZZX &amp;poly, const FHEcontext &amp;_context, const IndexSet &amp;indexSet)'],['../class_double_c_r_t.html#a4e8a56b5e7ff8d13ff2519f59eca444b',1,'DoubleCRT::DoubleCRT(const ZZX &amp;poly)'],['../class_double_c_r_t.html#a7414a52996d939c6725e6bf2fe070980',1,'DoubleCRT::DoubleCRT(const FHEcontext &amp;_context, const IndexSet &amp;indexSet)']]],
  ['doublecrt_2eh',['DoubleCRT.h',['../_double_c_r_t_8h.html',1,'']]],
  ['doublecrthelper',['DoubleCRTHelper',['../class_double_c_r_t_helper.html',1,'']]],
  ['dummy',['dummy',['../class_key_switch.html#a0c0bd2980985c1be3a03954ef71b34c3',1,'KeySwitch']]]
];
