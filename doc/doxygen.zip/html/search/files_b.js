var searchData=
[
  ['replicate_2eh',['replicate.h',['../replicate_8h.html',1,'']]]
];
