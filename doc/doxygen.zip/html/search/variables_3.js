var searchData=
[
  ['skhandle',['skHandle',['../class_ctxt_part.html#afa10a1dc1b5992d7e96777d5bb4b8cae',1,'CtxtPart']]],
  ['specialprimes',['specialPrimes',['../class_f_h_econtext.html#acb7fe42b373a82e9d1ba9ddf7a53b664',1,'FHEcontext']]],
  ['stdev',['stdev',['../class_f_h_econtext.html#aedf457d19258dade564cc32e01d623f5',1,'FHEcontext']]]
];
