var searchData=
[
  ['nativedimension',['nativeDimension',['../class_encrypted_array_base.html#acefe1ea064deee5d0ac418d4d2fbec80',1,'EncryptedArrayBase']]],
  ['next',['next',['../class_index_set.html#afbea26242c2490dc6bdcd2484333e34f',1,'IndexSet']]],
  ['nextexpvector',['nextExpVector',['../class_p_algebra.html#a78a0a480a762c5ea962edf92b6b49611',1,'PAlgebra']]],
  ['numcols',['numCols',['../class_cube_signature.html#a8fe9b687f4d1f3e64e1d90d86eb19fd3',1,'CubeSignature::numCols()'],['../class_hyper_cube.html#a29f6b01ec78b80f486c9a4bd4694fc9e',1,'HyperCube::numCols()'],['../class_const_cube_slice.html#a29c5f65c7ad86e5adb4312d2dac0e960',1,'ConstCubeSlice::numCols()']]],
  ['numofgens',['numOfGens',['../class_p_algebra.html#a21297b51dc6aceb03a3a1846259271f8',1,'PAlgebra']]],
  ['numprimes',['numPrimes',['../class_f_h_econtext.html#af2c0668bb5a3553b14acd345c4e2a224',1,'FHEcontext']]],
  ['numslices',['numSlices',['../class_cube_signature.html#a7f8a252b33ac49ef2b6bb86174139821',1,'CubeSignature::numSlices()'],['../class_hyper_cube.html#a6488a665f8f7d5e78d07d112ed09b8d7',1,'HyperCube::numSlices()'],['../class_const_cube_slice.html#ac75cfa4edf54ead2cd28970d13461dc9',1,'ConstCubeSlice::numSlices()']]]
];
