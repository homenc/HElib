var searchData=
[
  ['blindctxt',['blindCtxt',['../class_ctxt.html#aae945608631387aa9d81a4d3c5301e63',1,'Ctxt']]],
  ['bluesteinfft',['BluesteinFFT',['../bluestein_8h.html#ac0de059ed9b0f07e4af5558c59c53c41',1,'BluesteinFFT(ZZ_pX &amp;x, long n, const ZZ_p &amp;root, ZZ_pX &amp;powers, Vec&lt; mulmod_precon_t &gt; &amp;powers_aux, FFTRep &amp;Rb, fftrep_aux &amp;Rb_aux, FFTRep &amp;Ra):&#160;bluestein.cpp'],['../bluestein_8h.html#a495a21409eaf70d7609ecf90c2bd3f4e',1,'BluesteinFFT(zz_pX &amp;x, long n, const zz_p &amp;root, zz_pX &amp;powers, Vec&lt; mulmod_precon_t &gt; &amp;powers_aux, fftRep &amp;Rb, fftrep_aux &amp;Rb_aux, fftRep &amp;Ra):&#160;bluestein.cpp']]],
  ['breakintodigits',['breakIntoDigits',['../class_double_c_r_t.html#aaf1c74e47e26c843e2c6988cb4771028',1,'DoubleCRT']]],
  ['breakpermbydim',['breakPermByDim',['../permutations_8h.html#acfb69ce1781dcd4e8623060b068dc45e',1,'permutations.cpp']]],
  ['buildencryptedarray',['buildEncryptedArray',['../_encrypted_array_8h.html#a3e2ffedb8bdcdd3a9317b240cd81fb80',1,'EncryptedArray.cpp']]],
  ['buildlinpolycoeffs',['buildLinPolyCoeffs',['../class_encrypted_array_base.html#aaaade725d202622fbf5cb2f5409a9ff6',1,'EncryptedArrayBase::buildLinPolyCoeffs()'],['../class_encrypted_array_derived.html#a7a98a620a0796a908ad118a81ef6f93d',1,'EncryptedArrayDerived::buildLinPolyCoeffs()'],['../class_p_algebra_mod_derived.html#ace735293476d9c20433e66b5e44bb779',1,'PAlgebraModDerived::buildLinPolyCoeffs()'],['../_numb_th_8h.html#a4ee9775cdc72b31e5e94d6fcdb2b67e7',1,'buildLinPolyCoeffs(vec_zz_pE &amp;C, const vec_zz_pE &amp;L, long p, long r):&#160;NumbTh.cpp'],['../_numb_th_8h.html#ab6cadd3b8e7b42be5ba44fea50e83490',1,'buildLinPolyCoeffs(vec_GF2E &amp;C, const vec_GF2E &amp;L, long p, long r):&#160;NumbTh.cpp']]],
  ['buildmodchain',['buildModChain',['../_f_h_e_context_8h.html#a045c364e311627ff3f610f06d0297f29',1,'FHEContext.cpp']]],
  ['buildnetwork',['buildNetwork',['../class_perm_network.html#afd092d88506e2f1eb34dd1b1bb9892d1',1,'PermNetwork']]],
  ['buildoptimaltrees',['buildOptimalTrees',['../class_generator_trees.html#a866eb8a43b731ad3e9f79489127b1b6e',1,'GeneratorTrees']]],
  ['buildpalgebramod',['buildPAlgebraMod',['../_p_algebra_8h.html#a0cddefef0874d3c0e02bde6c43bb56e9',1,'PAlgebra.cpp']]],
  ['buildplaintextarray',['buildPlaintextArray',['../_encrypted_array_8h.html#abccd4ae3bfd0a558c9991b520445e80d',1,'EncryptedArray.cpp']]]
];
