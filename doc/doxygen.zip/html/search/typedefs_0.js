var searchData=
[
  ['permut',['Permut',['../permutations_8h.html#afbf70f35cad3d41acf8d07896c3f3060',1,'permutations.h']]]
];
